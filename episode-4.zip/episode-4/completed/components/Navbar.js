'use client';

import Link from 'next/link';
import { useCart } from '@/lib/cart-context';
import styles from './Navbar.module.css';

export default function Navbar() {
  const { count } = useCart();

  return (
    <header className={styles.header}>
      <div className="container">
        <nav className={styles.nav}>
          <Link href="/" className={styles.brand}>
            Storefront
          </Link>
          <div className={styles.links}>
            <Link href="/about">About</Link>
            <Link href="/store">Store</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/cart">Cart{count > 0 ? ` (${count})` : ''}</Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
