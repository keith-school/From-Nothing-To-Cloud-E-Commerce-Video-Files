'use client';

import { useCart } from '@/lib/cart-context';
import styles from './ProductCard.module.css';

export default function ProductCard({ product }) {
  const { addItem } = useCart();

  return (
    <article className={styles.card}>
      <div className={styles.image}>
        <span>{product.name}</span>
      </div>
      <div className={styles.body}>
        <h3>{product.name}</h3>
        <p>{product.description}</p>
        <div className={styles.row}>
          <span className={styles.price}>${product.price}</span>
          <button type="button" className="btn btn-secondary" onClick={() => addItem(product)}>
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}
