import Link from 'next/link';
import styles from './page.module.css';
import ProductCard from '@/components/ProductCard';
import { products } from '@/lib/products';

export default function Home() {
  const featured = products.slice(0, 3);

  return (
    <div>
      <section className={styles.hero}>
        <div className="container">
          <h1 className={styles.title}>Example Store</h1>
          <p className={styles.subtitle}>
            This episode focuses on the shared layout and app shell you will expand through the rest of the series.
          </p>
          <Link href="/store" className="btn btn-primary">
            Explore the store
          </Link>
        </div>
      </section>

      <section className="container">
        <h2 className={styles.sectionTitle}>Featured products</h2>
        <div className={styles.grid}>
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </div>
  );
}
