import styles from './page.module.css';
import ProductCard from '@/components/ProductCard';
import { products } from '@/lib/products';

export default function StorePage() {
  return (
    <div className="container">
      <div className={styles.header}>
        <h1>Store</h1>
        <p className={styles.subtitle}>Browse the full catalog.</p>
      </div>
      <div className={styles.grid}>
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
