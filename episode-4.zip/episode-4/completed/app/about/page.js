export default function AboutPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>About</h1>
      <p>Now you can access this page.</p>
    </main>
  );
}
