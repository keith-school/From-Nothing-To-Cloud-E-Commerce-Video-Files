'use client';

import Link from 'next/link';
import { useCart } from '@/lib/cart-context';
import styles from './page.module.css';

export default function CartPage() {
  const { items, updateQuantity, removeItem, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="container">
        <div className={styles.header}>
          <h1>Cart</h1>
        </div>
        <p>
          Your cart is empty. <Link href="/store">Browse the store</Link> to add something.
        </p>
      </div>
    );
  }

  return (
    <div className="container">
      <div className={styles.header}>
        <h1>Cart</h1>
      </div>
      <ul className={styles.list}>
        {items.map((item) => (
          <li key={item.id} className={styles.item}>
            <div className={styles.itemInfo}>
              <span className={styles.itemName}>{item.name}</span>
              <span className={styles.itemPrice}>${item.price}</span>
            </div>
            <div className={styles.quantity}>
              <button type="button" onClick={() => updateQuantity(item.id, item.quantity - 1)}>
                -
              </button>
              <span>{item.quantity}</span>
              <button type="button" onClick={() => updateQuantity(item.id, item.quantity + 1)}>
                +
              </button>
            </div>
            <button type="button" className={styles.remove} onClick={() => removeItem(item.id)}>
              Remove
            </button>
          </li>
        ))}
      </ul>
      <div className={styles.summary}>
        <span>Total</span>
        <span className={styles.total}>${total}</span>
      </div>
      <div className={styles.actions}>
        <Link href="/checkout" className="btn btn-primary">
          Checkout
        </Link>
      </div>
    </div>
  );
}
