export async function POST(request) {
  const body = await request.json();

  if (!body.items || body.items.length === 0) {
    return Response.json({ error: 'Your cart is empty.' }, { status: 400 });
  }

  // Placeholder for a real backend call. A future episode swaps this for a
  // request to the deployed API, which creates a real Stripe Checkout session.
  await new Promise((resolve) => setTimeout(resolve, 600));

  return Response.json({ url: '/checkout/success' });
}
