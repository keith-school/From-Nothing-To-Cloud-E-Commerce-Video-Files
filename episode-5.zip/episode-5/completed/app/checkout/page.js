'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/lib/cart-context';
import styles from './page.module.css';

export default function CheckoutPage() {
  const { items, total } = useCart();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleCheckout = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong. Please try again.');
      }

      window.location.href = data.url;
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="container">
        <div className={styles.header}>
          <h1>Checkout</h1>
        </div>
        <p>
          Your cart is empty. <Link href="/store">Browse the store</Link> before checking out.
        </p>
      </div>
    );
  }

  return (
    <div className="container">
      <div className={styles.header}>
        <h1>Checkout</h1>
        <p className={styles.subtitle}>Review your order before you pay.</p>
      </div>

      <ul className={styles.list}>
        {items.map((item) => (
          <li key={item.id} className={styles.item}>
            <span>
              {item.name} <span className={styles.qty}>x{item.quantity}</span>
            </span>
            <span>${item.price * item.quantity}</span>
          </li>
        ))}
      </ul>

      <div className={styles.summary}>
        <span>Total</span>
        <span className={styles.total}>${total}</span>
      </div>

      {error ? <p className={styles.error}>{error}</p> : null}

      <button
        type="button"
        className="btn btn-primary"
        onClick={handleCheckout}
        disabled={loading}
      >
        {loading ? 'Redirecting to payment...' : 'Place order'}
      </button>

      <p className={styles.note}>
        This calls a placeholder checkout API for now — a future episode wires it up to a real
        backend and Stripe Checkout.
      </p>
    </div>
  );
}
