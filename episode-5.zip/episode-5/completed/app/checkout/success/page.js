import Link from 'next/link';
import styles from './page.module.css';

export default function CheckoutSuccessPage() {
  return (
    <div className="container">
      <div className={styles.wrapper}>
        <h1>Thanks for your order!</h1>
        <p className={styles.subtitle}>This is a placeholder confirmation page for now.</p>
        <Link href="/store" className="btn btn-primary">
          Continue shopping
        </Link>
      </div>
    </div>
  );
}
