export default function StorePage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Store</h1>
      <p>Now you can access this page.</p>
    </main>
  );
}
