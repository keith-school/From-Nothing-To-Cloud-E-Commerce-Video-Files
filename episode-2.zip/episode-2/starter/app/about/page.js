export default function AboutPage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>About</h1>
      <p>This page will be filled in later.</p>
    </main>
  );
}
