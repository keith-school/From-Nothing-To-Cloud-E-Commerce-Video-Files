import styles from './page.module.css';

export default function HomePage() {
  return (
    <main className={styles.main}>
      <h1>Starter page</h1>
      <p>Start working from here.</p>
    </main>
  );
}
