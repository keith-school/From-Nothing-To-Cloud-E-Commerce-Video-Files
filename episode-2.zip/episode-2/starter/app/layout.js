import './globals.css';

export const metadata = {
  title: 'Episode 2 Starter',
  description: 'A blank-slate starter project for the Episode 2 tutorial.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
