export default function StorePage() {
  return (
    <main style={{ padding: '2rem' }}>
      <h1>Store</h1>
      <p>This page will be filled in later.</p>
    </main>
  );
}
