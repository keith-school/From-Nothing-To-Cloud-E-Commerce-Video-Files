import Link from 'next/link';
import styles from './Navbar.module.css';

export default function Navbar() {
  return (
    <header className={styles.header}>
      <div className="container">
        <nav className={styles.nav}>
          <Link href="/" className={styles.brand}>
            Storefront
          </Link>
          <div className={styles.links}>
            <Link href="/about">About</Link>
            <Link href="/store">Store</Link>
            <Link href="/contact">Contact</Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
