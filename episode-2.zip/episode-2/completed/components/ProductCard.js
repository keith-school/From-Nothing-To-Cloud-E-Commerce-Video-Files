import Link from 'next/link';
import styles from './ProductCard.module.css';

export default function ProductCard({ product }) {
  return (
    <article className={styles.card}>
      <div className={styles.image}>
        <span>{product.name}</span>
      </div>
      <div className={styles.body}>
        <h3>{product.name}</h3>
        <p>{product.description}</p>
        <div className={styles.row}>
          <span className={styles.price}>${product.price}</span>
          <Link href="/store" className="btn btn-secondary">
            View details
          </Link>
        </div>
      </div>
    </article>
  );
}
